﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;
using Exercise.DataAccess;
using Exercise.DataAccess.Http;
using Exercise.Services;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.HttpsPolicy;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Options;

namespace Exercise.Api
{
    public class Startup
    {
        public Startup(IConfiguration configuration)
        {
            Configuration = configuration;
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddMvc().SetCompatibilityVersion(CompatibilityVersion.Version_2_2);

            ConfigureDependencies(services);
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IHostingEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
            }
            else
            {
                // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
                app.UseHsts();
            }

            app.UseHttpsRedirection();
            app.UseMvc();
        }

        private void ConfigureDependencies(IServiceCollection services)
        {
            var httpClient = new HttpClient();
            
            services.AddSingleton<IAlbumDataProvider, HttpAlbumDataProvider>(serviceProvider =>
            {
                var logger = serviceProvider.GetRequiredService<ILogger<HttpAlbumDataProvider>>();
                var albumsUrl = Configuration.GetValue<string>("AlbumsUrl");

                return new HttpAlbumDataProvider(logger, httpClient, albumsUrl);
            });

            services.AddSingleton<IPhotoDataProvider, HttpPhotoDataProvider>(serviceProvider =>
            {
                var logger = serviceProvider.GetRequiredService<ILogger<HttpPhotoDataProvider>>();
                var photosUrl = Configuration.GetValue<string>("PhotosUrl");

                return new HttpPhotoDataProvider(logger, httpClient, photosUrl);
            });

            services.AddSingleton<IAlbumsService, AlbumsService>();
        }
    }
}
