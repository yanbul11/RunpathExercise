﻿using Exercise.Services;
using Exercise.Services.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Newtonsoft.Json.Serialization;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Exercise.Api.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AlbumsController : ControllerBase
    {
        private readonly static JsonSerializerSettings SerializerSettings = new JsonSerializerSettings()
        {
            ContractResolver = new CamelCasePropertyNamesContractResolver(),
            Formatting = Formatting.Indented            
        };

        private readonly IAlbumsService _albumsService;

        public AlbumsController(ILogger<AlbumsController> logger, IAlbumsService albumsService)
        {
            if (albumsService == null)
                throw new ArgumentNullException(nameof(albumsService));

            _albumsService = albumsService;
        }

        // GET api/albums
        [HttpGet]
        public async Task<ActionResult<IEnumerable<AlbumDto>>> Get()
        {
            var albums = await _albumsService.GetAlbumsAsync();

            if (albums == null)
                return BadRequest();

            return new JsonResult(albums, SerializerSettings);
        }

        // GET api/albums/[userId]
        [HttpGet("{userId}")]
        public async Task<ActionResult<IEnumerable<AlbumDto>>> Get(int userId)
        {
            var albums = await _albumsService.GetAlbumsAsync(userId);

            if (albums == null)
                return BadRequest();

            return new JsonResult(albums, SerializerSettings);
        }
    }
}
