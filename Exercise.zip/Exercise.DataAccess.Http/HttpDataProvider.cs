﻿using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Net;
using System.Net.Http;
using System.Threading.Tasks;

namespace Exercise.DataAccess.Http
{
    public abstract class HttpDataProvider
    {
        private readonly ILogger<HttpDataProvider> _logger;
        private readonly HttpClient _client;

        protected HttpDataProvider(ILogger<HttpDataProvider> logger, HttpClient client, string url)
        {
            if (logger == null)
                throw new ArgumentNullException(nameof(logger));

            if (client == null)
                throw new ArgumentNullException(nameof(client));

            if (url == null)
                throw new ArgumentNullException(nameof(url));

            _logger = logger;
            _client = client;

            this.Url = url;
        }

        public string Url { get; }

        protected async Task<IEnumerable<T>> GetDataAsync<T>() where T : class
        {
            try
            {
                var response = await _client.GetAsync(Url);

                if (response.StatusCode != HttpStatusCode.OK)
                    return null;

                var content = await response.Content.ReadAsStringAsync();
                return JsonConvert.DeserializeObject<T[]>(content);
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "Error trying to get data from {Url}", Url);
                return null;
            }
        }
    }
}
