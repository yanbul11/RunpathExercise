﻿using Exercise.DataAccess.Models;
using Microsoft.Extensions.Logging;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Exercise.DataAccess.Http
{
    public class HttpAlbumDataProvider : HttpDataProvider, IAlbumDataProvider
    {
        public HttpAlbumDataProvider(ILogger<HttpAlbumDataProvider> logger, HttpClient client, string url) : base(logger, client, url)
        {
        }

        public async Task<IEnumerable<AlbumDao>> GetAlbumsAsync()
        {
            return await GetDataAsync<AlbumDao>();
        }

        public async Task<IEnumerable<AlbumDao>> GetAlbumsAsync(int userId)
        {
            var albums = await GetAlbumsAsync();

            return albums == null ? null : albums.Where(album => album.UserId == userId);
        }
    }
}
