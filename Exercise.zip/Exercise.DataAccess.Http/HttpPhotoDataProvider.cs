﻿using Exercise.DataAccess.Models;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Threading.Tasks;

namespace Exercise.DataAccess.Http
{
    public class HttpPhotoDataProvider : HttpDataProvider, IPhotoDataProvider
    {
        public HttpPhotoDataProvider(ILogger<HttpPhotoDataProvider> logger, HttpClient client, string url) : base(logger, client, url)
        {
        }

        public async Task<IEnumerable<PhotoDao>> GetPhotosAsync()
        {
            return await GetDataAsync<PhotoDao>();
        }

        public async Task<IEnumerable<PhotoDao>> GetPhotosAsync(IEnumerable<int> albumIds)
        {
            if (albumIds == null)
                throw new ArgumentNullException(nameof(albumIds));

            var photos = await GetPhotosAsync();
            var albumIdSet = new HashSet<int>(albumIds);

            return photos == null ? null : photos.Where(photo => albumIdSet.Contains(photo.AlbumId));
        }
    }
}
