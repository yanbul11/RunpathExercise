﻿using Exercise.DataAccess;
using Exercise.DataAccess.Models;
using Exercise.Services.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Exercise.Services
{
    public class AlbumsService : IAlbumsService
    {
        private readonly IAlbumDataProvider _albumDataProvider;
        private readonly IPhotoDataProvider _photoDataProvider;

        public AlbumsService(IAlbumDataProvider albumDataProvider, IPhotoDataProvider photoDataProvider)
        {
            if (albumDataProvider == null)
                throw new ArgumentNullException(nameof(albumDataProvider));

            if (photoDataProvider == null)
                throw new ArgumentNullException(nameof(photoDataProvider));

            _albumDataProvider = albumDataProvider;
            _photoDataProvider = photoDataProvider;
        }

        public async Task<IEnumerable<AlbumDto>> GetAlbumsAsync()
        {
            var albums = await _albumDataProvider.GetAlbumsAsync();

            if (albums == null)
                return null;

            var photos = await _photoDataProvider.GetPhotosAsync();

            if (photos == null)
                return null;

            return CreateDto(albums, photos);
        }

        public async Task<IEnumerable<AlbumDto>> GetAlbumsAsync(int userId)
        {
            var albums = await _albumDataProvider.GetAlbumsAsync(userId);

            if (albums == null)
                return null;

            if (!albums.Any())
                return new AlbumDto[] { };

            var albumIds = from album in albums select album.Id;
            var photos = await _photoDataProvider.GetPhotosAsync(albumIds);

            if (photos == null)
                return null;

            return CreateDto(albums, photos);
        }

        private static AlbumDto CreateDto(AlbumDao album, IEnumerable<PhotoDao> photos)
        {
            return new AlbumDto
            {
                Id = album.Id,
                UserId = album.UserId,
                Title = album.Title,
                Photos = from photo in photos select CreateDto(photo)
            };
        }

        private static PhotoDto CreateDto(PhotoDao photo)
        {
            return new PhotoDto
            {
                Id = photo.Id,
                Title = photo.Title,
                Url = photo.Url,
                ThumbnailUrl = photo.ThumbnailUrl
            };
        }

        private static IEnumerable<AlbumDto> CreateDto(IEnumerable<AlbumDao> albums, IEnumerable<PhotoDao> photos)
        {
            return from album in albums
                   select CreateDto(album, photos.Where(photo => photo.AlbumId == album.Id));
        }
    }
}
