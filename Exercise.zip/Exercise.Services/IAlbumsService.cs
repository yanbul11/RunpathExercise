﻿using Exercise.Services.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Exercise.Services
{
    public interface IAlbumsService
    {
        Task<IEnumerable<AlbumDto>> GetAlbumsAsync();

        Task<IEnumerable<AlbumDto>> GetAlbumsAsync(int userId);
    }
}
