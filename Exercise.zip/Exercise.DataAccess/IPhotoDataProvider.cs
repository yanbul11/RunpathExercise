﻿using Exercise.DataAccess.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Exercise.DataAccess
{
    public interface IPhotoDataProvider
    {
        Task<IEnumerable<PhotoDao>> GetPhotosAsync();

        Task<IEnumerable<PhotoDao>> GetPhotosAsync(IEnumerable<int> albumIds);
    }
}
