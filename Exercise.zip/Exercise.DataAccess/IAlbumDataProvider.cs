﻿using Exercise.DataAccess.Models;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace Exercise.DataAccess
{
    public interface IAlbumDataProvider
    {
        Task<IEnumerable<AlbumDao>> GetAlbumsAsync();

        Task<IEnumerable<AlbumDao>> GetAlbumsAsync(int userId);
    }
}
