﻿namespace Exercise.DataAccess.Models
{
    public class AlbumDao
    {
        public int Id { get; set; }

        public int UserId { get; set; }

        public string Title { get; set; }
    }
}
