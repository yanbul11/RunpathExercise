﻿namespace Exercise.Services.Test
{
    internal sealed class TestData
    {
        public static string Albums = @"
            [
              {
                ""userId"": 1,
                ""id"": 1,
                ""title"": ""quidem molestiae enim""
              },
              {
                ""userId"": 1,
                ""id"": 2,
                ""title"": ""sunt qui excepturi placeat culpa""
              },
              {
                ""userId"": 2,
                ""id"": 3,
                ""title"": ""consequatur autem doloribus natus consectetur""
              },
              {
                ""userId"": 2,
                ""id"": 4,
                ""title"": ""ab rerum non rerum consequatur ut ea unde""
              }
            ]";

        public static string Photos = @"
            [
              {
                ""albumId"": 1,
                ""id"": 1,
                ""title"": ""accusamus beatae ad facilis cum similique qui sunt"",
                ""url"": ""https://via.placeholder.com/600/92c952"",
                ""thumbnailUrl"": ""https://via.placeholder.com/150/92c952""
              },
              {
                ""albumId"": 1,
                ""id"": 2,
                ""title"": ""reprehenderit est deserunt velit ipsam"",
                ""url"": ""https://via.placeholder.com/600/771796"",
                ""thumbnailUrl"": ""https://via.placeholder.com/150/771796""
              },
            {
                ""albumId"": 2,
                ""id"": 3,
                ""title"": ""non sunt voluptatem placeat consequuntur rem incidunt"",
                ""url"": ""https://via.placeholder.com/600/8e973b"",
                ""thumbnailUrl"": ""https://via.placeholder.com/150/8e973b""
              },
              {
                ""albumId"": 2,
                ""id"": 4,
                ""title"": ""eveniet pariatur quia nobis reiciendis laboriosam ea"",
                ""url"": ""https://via.placeholder.com/600/121fa4"",
                ""thumbnailUrl"": ""https://via.placeholder.com/150/121fa4""
              },
              {
                ""albumId"": 3,
                ""id"": 5,
                ""title"": ""eveniet debitis nihil"",
                ""url"": ""https://via.placeholder.com/600/21e334"",
                ""thumbnailUrl"": ""https://via.placeholder.com/150/21e334""
              },
              {
                ""albumId"": 3,
                ""id"": 6,
                ""title"": ""odit culpa optio nesciunt"",
                ""url"": ""https://via.placeholder.com/600/b56655"",
                ""thumbnailUrl"": ""https://via.placeholder.com/150/b56655""
              },
              {
                ""albumId"": 4,
                ""id"": 7,
                ""title"": ""dolor delectus nemo quas nobis beatae omnis"",
                ""url"": ""https://via.placeholder.com/600/bcaaed"",
                ""thumbnailUrl"": ""https://via.placeholder.com/150/bcaaed""
              },
              {
                ""albumId"": 4,
                ""id"": 8,
                ""title"": ""id sint pariatur reiciendis soluta animi"",
                ""url"": ""https://via.placeholder.com/600/70c4ab"",
                ""thumbnailUrl"": ""https://via.placeholder.com/150/70c4ab""
              }
            ]";
    }
}
