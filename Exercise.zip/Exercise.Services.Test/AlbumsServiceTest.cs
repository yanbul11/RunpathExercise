using Exercise.DataAccess.Http;
using Microsoft.Extensions.Logging;
using Moq;
using Moq.Protected;
using NUnit.Framework;
using System;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Threading;
using System.Threading.Tasks;

namespace Exercise.Services.Test
{
    public class AlbumsServiceTest
    {
        [Test]
        public async Task TestGetAlbums()
        {
            // Arrange

            var fakeUri = new Uri("http://www.test.com/");

            var albumDataProviderLogger = new Mock<ILogger<HttpAlbumDataProvider>>();
            var albumsResponseMessage = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(TestData.Albums) };
            var albumsHttpMessageHandler = new Mock<HttpMessageHandler>();

            albumsHttpMessageHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(albumsResponseMessage);

            var albumsHttpClient = new HttpClient(albumsHttpMessageHandler.Object) { BaseAddress = fakeUri };
            var albumDataProvider = new Mock<HttpAlbumDataProvider>(albumDataProviderLogger.Object, albumsHttpClient, "");

            var photoDataProviderLogger = new Mock<ILogger<HttpPhotoDataProvider>>();
            var photosResponseMessage = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(TestData.Photos) };
            var photosHttpMessageHandler = new Mock<HttpMessageHandler>();

            photosHttpMessageHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(photosResponseMessage);

            var photosHttpClient = new HttpClient(photosHttpMessageHandler.Object) { BaseAddress = fakeUri };
            var photoDataProvider = new Mock<HttpPhotoDataProvider>(photoDataProviderLogger.Object, photosHttpClient, "");

            var albumService = new AlbumsService(albumDataProvider.Object, photoDataProvider.Object);

            // Act

            var albums = await albumService.GetAlbumsAsync();

            // Assert
            Assert.NotNull(albums);
            Assert.AreEqual(4, albums.Count());

            CollectionAssert.AreEquivalent(new int[] { 1, 2 }, from photo in albums.First(album => album.Id == 1).Photos select photo.Id);
            CollectionAssert.AreEquivalent(new int[] { 3, 4 }, from photo in albums.First(album => album.Id == 2).Photos select photo.Id);
            CollectionAssert.AreEquivalent(new int[] { 5, 6 }, from photo in albums.First(album => album.Id == 3).Photos select photo.Id);
            CollectionAssert.AreEquivalent(new int[] { 7, 8 }, from photo in albums.First(album => album.Id == 4).Photos select photo.Id);
        }

        [Test]
        [TestCase(1, new int[] { 1, 2 }, new int[] { 1, 2 }, new int[] { 3, 4 })] // User 1: albums 1, 2 with photos { 1, 2 } and { 3, 4 }
        [TestCase(2, new int[] { 3, 4 }, new int[] { 5, 6 }, new int[] { 7, 8 })] // User 2: albums 3, 4 with photos { 5, 6 } and { 7, 8 }
        public async Task TestGetAlbumsByUser(int userId, int[] expectedAlbumIds, params int[][] expectedPhotoIdArrays)
        {
            // Arrange

            var fakeUri = new Uri("http://www.test.com/");

            var albumDataProviderLogger = new Mock<ILogger<HttpAlbumDataProvider>>();
            var albumsResponseMessage = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(TestData.Albums) };
            var albumsHttpMessageHandler = new Mock<HttpMessageHandler>();

            albumsHttpMessageHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(albumsResponseMessage);

            var albumsHttpClient = new HttpClient(albumsHttpMessageHandler.Object) { BaseAddress = fakeUri };
            var albumDataProvider = new Mock<HttpAlbumDataProvider>(albumDataProviderLogger.Object, albumsHttpClient, "");

            var photoDataProviderLogger = new Mock<ILogger<HttpPhotoDataProvider>>();
            var photosResponseMessage = new HttpResponseMessage(HttpStatusCode.OK) { Content = new StringContent(TestData.Photos) };
            var photosHttpMessageHandler = new Mock<HttpMessageHandler>();

            photosHttpMessageHandler
                .Protected()
                .Setup<Task<HttpResponseMessage>>(
                    "SendAsync",
                    ItExpr.IsAny<HttpRequestMessage>(),
                    ItExpr.IsAny<CancellationToken>())
                .ReturnsAsync(photosResponseMessage);

            var photosHttpClient = new HttpClient(photosHttpMessageHandler.Object) { BaseAddress = fakeUri };
            var photoDataProvider = new Mock<HttpPhotoDataProvider>(photoDataProviderLogger.Object, photosHttpClient, "");

            var albumService = new AlbumsService(albumDataProvider.Object, photoDataProvider.Object);

            // Act

            var albums = await albumService.GetAlbumsAsync(userId);

            // Assert
            Assert.NotNull(albums);
            Assert.AreEqual(expectedAlbumIds.Length, albums.Count());

            for (var i = 0; i < expectedAlbumIds.Length; i++)
            {
                var expectedAlbumId = expectedAlbumIds[i];
                var expectedPhotoIds = expectedPhotoIdArrays[i];

                var expectedAlbum = albums.First(album => album.Id == expectedAlbumId);

                Assert.NotNull(expectedAlbum);
                CollectionAssert.AreEquivalent(expectedPhotoIds, from photo in expectedAlbum.Photos select photo.Id);
            }
        }
    }
}